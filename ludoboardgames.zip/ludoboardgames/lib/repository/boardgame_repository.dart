import 'package:ludoboardgames/model/boardgame.dart';
import 'package:ludoboardgames/model/game_publisher.dart';
import 'package:ludoboardgames/repository/game_publisher_repository.dart';

List<BoardGame> getAllBoardGames() {
  return [
    BoardGame(
      title: "Azul",
      gamesPublisher: [asmodee],
      imgPath: "assets/imgs/azul.jpg",
    ),
    BoardGame(
      title: "Ticket To Ride",
      gamesPublisher: [asmodee],
      imgPath: "assets/imgs/tickettoride.jpg",
    ),
    BoardGame(
      title: "Quem Foi?",
      gamesPublisher: [paperGames],
      imgPath: "assets/imgs/quemfoi.jpg",
    ),
  ];
}

List<BoardGame> getBoardGamesBy(GamePublisher gamePublisher) {
  return getAllBoardGames()
      .where((boardGame) => boardGame.gamesPublisher.contains(gamePublisher))
      .toList();
}
