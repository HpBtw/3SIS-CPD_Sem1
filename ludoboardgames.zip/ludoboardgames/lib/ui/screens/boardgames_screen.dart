import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:ludoboardgames/model/boardgame.dart';
import 'package:ludoboardgames/model/game_publisher.dart';
import 'package:ludoboardgames/repository/boardgame_repository.dart';
import 'package:ludoboardgames/repository/game_publisher_repository.dart';
import 'package:ludoboardgames/ui/components/game_publisher_card.dart';
import 'package:ludoboardgames/ui/components/top_bar.dart';

class BoardGamesScreen extends StatefulWidget {
  const BoardGamesScreen({super.key});

  @override
  State<BoardGamesScreen> createState() => _BoardGamesScreenState();
}

class _BoardGamesScreenState extends State<BoardGamesScreen> {
  late List<GamePublisher> gamesPublisherState;
  late List<BoardGame> boardGamesListState;

  @override
  void initState() {
    super.initState();
    gamesPublisherState = getAllGamesPublishers();
    boardGamesListState = getAllBoardGames();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: LudoBGTopBar(
        actions: [
          IconButton(
            onPressed: () {
              // ação
            },
            icon: const Icon(Icons.notifications),
            tooltip: 'Notificações',
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
        child: SizedBox(
          width: double.infinity,
          height: double.infinity,
          child: Column(
            children: [
              SizedBox(
                height: 96,
                width: double.infinity,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: gamesPublisherState.length,
                  separatorBuilder: (_, _) => const SizedBox(width: 16),
                  itemBuilder: (context, index) {
                    final publisher = gamesPublisherState[index];
                    return GamePublisherCard(
                      gamePublisher: publisher,
                      onClick: (publisher) {
                        setState(() {
                          boardGamesListState = getBoardGamesBy(publisher);
                        });
                      },
                    );
                  },
                ),
              ),
              Divider(height: 1, color: Colors.grey),
              Padding(
                padding: const EdgeInsets.fromLTRB(5, 10, 5, 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Jogos ${boardGamesListState.}")
                  ]),
              ),
              // widgets aqui
            ],
          ),
        ),
      ),
    );
  }
}

class MouseScrollBehavior extends MaterialScrollBehavior {
  @override
  Set<PointerDeviceKind> get dragDevices => {
    PointerDeviceKind.touch,
    PointerDeviceKind.mouse,
    PointerDeviceKind.trackpad,
  };
}
